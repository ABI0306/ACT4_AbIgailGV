package control;

import dao.DAOAlumno;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Alumno;

@WebServlet("/Servlet")
public class Servlet_Alumno1 extends HttpServlet 
{
    private Alumno alumno;
    private DAOAlumno dao;

    @Override
    public void init() throws ServletException 
    {
        dao = new DAOAlumno();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) 
    {
        response.setContentType("text/html;charset=UTF-8");
        String accion = request.getParameter("accion");
        Alumno edit = null;
        
        try 
        {
            if (accion != null) 
            {
                switch (accion) 
                {
                    case "Agregar":
                        agregarAlumno(request);
                        break;
                    case "Modificar":
                        modificarAlumno(request);
                        break;
                    case "Editar":
                        edit = editarAlumno(request);
                        break;
                    case "Eliminar":
                        eliminarAlumno(request);
                        break;
                }
            }
            
            request.setAttribute("edit", edit);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/alumnos.jsp");
            rd.forward(request, response);
        } catch (IOException | ServletException ex) 
        {
            Logger.getLogger(Servlet_Alumno1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void agregarAlumno(HttpServletRequest request) 
    {
        alumno = new Alumno();
        alumno.setnL(Integer.parseInt(request.getParameter("tfnL")));
        alumno.setNombre(request.getParameter(              "tfNombre"));
        alumno.setPaterno(request.getParameter(               "tfPaterno"));
        alumno.setMaterno(request.getParameter(              "tfMaterno"));
        dao.agregar(alumno);
    }

    private void modificarAlumno(HttpServletRequest request) 
    {
        alumno = new Alumno();
        alumno.setnL(Integer.parseInt(request.getParameter("tfnL")));
        alumno.setNombre(request.getParameter(              "tfNombre"));
        alumno.setPaterno(request.getParameter(               "tfPaterno"));
        alumno.setMaterno(request.getParameter(              "tfMaterno"));
        int nLOld = Integer.parseInt(request.getParameter(          "tfnLOld"));
        dao.modificar(alumno, nLOld);
    }

    private Alumno editarAlumno(HttpServletRequest request)
    {
        int nL = Integer.parseInt(request.getParameter("tdnL"));
        return dao.buscar(nL);
    }

    private void eliminarAlumno(HttpServletRequest request) 
    {
        int nL = Integer.parseInt(request.getParameter("tdnL"));
        dao.eliminar(nL);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() 
    {
        return "Servlet para manejar operaciones CRUD de alumnos";
    }
}