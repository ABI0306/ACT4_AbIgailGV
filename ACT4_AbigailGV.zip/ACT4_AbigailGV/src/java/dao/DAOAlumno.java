package dao;

import conexion.ConexionMySQL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Alumno;

public class DAOAlumno 
{
    private Connection con;
    private PreparedStatement ps;
    private ResultSet rs;
    private Alumno alumno;

    public ArrayList<Alumno> listar()
    {
        ArrayList<Alumno> list = new ArrayList<>();
        String sql = "SELECT * FROM alumnos";

        try
        {
            con = ConexionMySQL.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) 
            {
                alumno = new Alumno();
                alumno.setnL(rs.getInt("NL"));
                alumno.setNombre(rs.getString("Nombre"));
                alumno.setPaterno(rs.getString( "Paterno"));
                alumno.setMaterno(rs.getString("Materno"));
                list.add(alumno);
            }
        } catch (SQLException e) 
        {
            System.out.println("Error al listar: " + e.getMessage());
        } finally 
        {
            closeResources();
        }
        return list;
    }

    public String mostrar()
    {
        String r = """
          <br><br>
          <table border='1' style='width:100%; border-collapse: collapse;'>
            <caption style='font-weight: bold; font-size: 1.2em; margin-bottom: 10px;'>Lista de alumnos</caption>
            <thead style='background-color: #f2f2f2;'>
              <tr>
                <th>NL</th>
                <th>Nombre</th>
                <th>Paterno</th>
                <th>Materno</th>
                <th colspan='2'>Acciones</th>
              </tr>
            </thead>
            <tbody>
         """;
        
        for(Alumno reg : listar())
        {
            r += "<tr>\n"
              + "  <td style='padding: 8px; text-align: center;'>" + reg.getnL() + "</td>\n"
              + "  <td style='padding: 8px;'>" + reg.getNombre() + "</td>\n"
              + "  <td style='padding: 8px;'>" + reg.getPaterno() + "</td>\n"
              + "  <td style='padding: 8px;'>" + reg.getMaterno() + "</td>\n"
              + "  <td style='padding: 8px; text-align: center;'>\n"
              + "      <form method='post' action='Servlet'>\n"
              + "          <input type='hidden' name='accion' value='Editar'/>\n"
              + "          <input type='hidden' name='tdnL' value='" + reg.getnL() + "'/>\n"
              + "          <input type='submit' value='Editar' style='padding: 5px 10px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;'/>\n"
              + "      </form>\n"
              + "  </td>\n"
              + "  <td style='padding: 8px; text-align: center;'>\n"
              + "      <form method='post' action='Servlet'>\n"
              + "          <input type='hidden' name='accion' value='Eliminar'/>\n"
              + "          <input type='hidden' name='tdnL' value='" + reg.getnL() + "'/>\n"
              + "          <input type='submit' value='Eliminar' style='padding: 5px 10px; background-color: #f44336; color: white; border: none; border-radius: 4px; cursor: pointer;'/>\n"
              + "      </form>\n"
              + "  </td>\n"
              + "</tr>\n";  
        }
        r += "</tbody>\n</table>\n";
        return r;
    }

    public boolean agregar(Alumno a) 
    {
        String sql = "INSERT INTO alumnos (NL, Nombre, Paterno, Materno) VALUES (?, ?, ?, ?)";
        try 
        {
            con = ConexionMySQL.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, a.getnL());
            ps.setString(2, a.getNombre());
            ps.setString(3, a.getPaterno());
            ps.setString(4, a.getMaterno());
            return ps.executeUpdate() > 0;
        } catch (SQLException e)
        {
            System.out.println("Error al agregar: " + e.getMessage());
            return false;
        } finally 
        {
            closeResources();
        }
    }

    public boolean modificar(Alumno a, int nLOld)
    {
        String sql = "UPDATE alumnos SET NL=?, Nombre=?, Paterno=?, Materno=? WHERE NL=?";
        try 
        {
            con = ConexionMySQL.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, a.getnL());
            ps.setString(2, a.getNombre());
            ps.setString(3, a.getPaterno());
            ps.setString(4, a.getMaterno());
            ps.setInt(5, nLOld);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) 
        {
            System.out.println("Error al modificar: " + e.getMessage());
            return false;
        } finally 
        {
            closeResources();
        }
    }

    public boolean eliminar(int nL)
    {
        String sql = "DELETE FROM alumnos WHERE NL=?";
        try 
        {
            con = ConexionMySQL.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, nL);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) 
        {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        } finally 
        {
            closeResources();
        }
    }

    public Alumno buscar(int nL) 
    {
        String sql = "SELECT * FROM alumnos WHERE NL=?";
        try 
        {
            con = ConexionMySQL.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, nL);
            rs = ps.executeQuery();
            if (rs.next()) 
            {
                alumno = new Alumno();
                alumno.setnL(rs.getInt("NL"));
                alumno.setNombre(rs.getString("Nombre"));
                alumno.setPaterno(rs.getString( "Paterno"));
                alumno.setMaterno(rs.getString("Materno"));
                return alumno;
            }
        } catch (SQLException e) 
        {
            System.out.println("Error al buscar: " + e.getMessage());
        } finally 
        {
            closeResources();
        }
        return null;
    }

    private void closeResources()
    {
        try 
        {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) 
        {
            System.out.println("Error al cerrar recursos: " + e.getMessage());
        }
    }
}