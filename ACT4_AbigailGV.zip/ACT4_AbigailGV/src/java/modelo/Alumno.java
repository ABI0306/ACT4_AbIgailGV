package modelo;


public class Alumno 
{
    private int nL;
    private String nombre;
    private String paterno;
    private String materno;

    public Alumno() 
    {
        this.nL=0;
        this.nombre="";
        this.paterno="";
        this.materno="";
    }

    public Alumno(int nL, String nombre, String paterno, String materno) 
    {
        this.nL = nL;
        this.nombre = nombre;
        this.paterno = paterno;
        this.materno = materno;
    }

    public int getnL() 
    {
        return nL;
    }

    public void setnL(int nL) 
    {
        this.nL = nL;
    }

    public String getNombre() 
    {
        return nombre;
    }

    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
    }

    public String getPaterno() 
    {
        return paterno;
    }

    public void setPaterno(String paterno) 
    {
        this.paterno = paterno;
    }

    public String getMaterno() 
    {
        return materno;
    }

    public void setMaterno(String materno) 
    {
        this.materno = materno;
    }
    
}
